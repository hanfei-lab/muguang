# 暮光 · Muguang

当前版本：0.2.2，修复锁屏/解锁或唤醒后暖光可能丢失且不再恢复的问题。

## 0.2.2 恢复机制

- 唤醒、屏幕点亮或会话恢复后，在 0.2、1.5、4、8、15 秒安排有限重试。每次读取当前设置，不缓存旧的色温或暂停状态。
- 普通检查改为约每 5 秒进行；暖光应生效时核对实际 gamma，确认丢失后重写。色彩正常时不重复写入。计时会受到系统调度影响，不承诺严格的恢复时限。
- 分开记录系统睡眠、屏幕睡眠与会话切换状态；保持原始校色表跨越临时断屏和挂起，避免把已有暖光再次当作原色。
- 补充屏幕唤醒通知。macOS 的分布式解锁通知仅作为尽力而为的辅助信号，收到后先确认当前用户位于控制台；公共通知及周期检查独立作为兜底。
- 暂停、关闭、白天定时状态会在每次重试时重新计算，不会因延迟回调重新开启暖光。

原生 macOS 菜单栏暖屏工具，Swift + AppKit，无第三方依赖。0.2.0 将 Intel 最低编译目标降到 macOS 10.15，Apple 芯片为 macOS 11。Catalina 实机验证尚未完成。

0.2.1 修复应用图标封装：以系统 ImageIO 编码器替代手工 PNG 拼装，提供旧式 16/32 像素 RGB 和透明蒙版、图层目录以及普通/Retina 全套尺寸；明确指定 `MuguangIcon-v021.icns`，同时递增构建版本。图案沿用原有日落设计，菜单栏图标与功能逻辑沿用 0.2.0。

## 构建

需要 Apple Command Line Tools；不要求安装完整 Xcode。源码中没有联网安装依赖的步骤。

```sh
bash test.sh
bash build.sh
```

默认输出 `../暮光.app`。可通过 `bash build.sh /完整路径/暮光.app` 指定输出。临时产物默认位于源码内 `work/build`，可用 `MUGUANG_BUILD_DIR` 环境变量覆盖。

构建脚本为 Intel 与 Apple 芯片分别编译后合并，绘制应用图标，最后执行本机临时签名和签名验证。此签名不等于开发者签名或 Apple 公证。

## 结构

- `Sources/Core.swift`：偏好设置、跨午夜定时、平滑渐变和相对 6500K 的近似 RGB 系数。
- `Sources/DisplayEngine.swift`：每屏 gamma 快照、动画、恢复、显示器枚举及恢复保护进程。通过 `DisplayAccess` 注入模拟显示器测试。
- `Sources/DisplayRecovery.swift`：系统/屏幕/会话状态与有限分阶段重试。
- `Sources/Panel.swift`：中文原生菜单栏弹出面板。
- `Sources/AppImages.swift`：自行绘制菜单栏与面板图标，无 SF Symbols 系统版本要求。
- `Sources/LoginController.swift`：macOS 13+ 使用 SMAppService，10.15–12 使用传统 Service Management 登录组件。
- `Sources/LoginSupport.swift`：辅助组件路径与旧版登录任务状态解析。
- `LoginHelper/`：旧系统的嵌入式登录启动组件，启动主应用后退出，不长期常驻。
- `Sources/main.swift`：生命周期、登录项、偏好保存、暂停、睡眠唤醒和命令行入口。
- `Tests/`：定时/色彩/设置、模拟多屏生命周期、旧版登录状态和安装包最低系统检查。
- `MakeIcon.swift`：按明确像素尺寸绘制图标，交给系统 ImageIO 编码 ICNS。

## 命令行

```sh
APP="../暮光.app/Contents/MacOS/Muguang"
"$APP" --diagnostics
"$APP" --smoke-test
"$APP" --preview /完整路径/暮光-界面.png
```

诊断为只读。界面自检和预览需在可访问桌面显示器的登录会话中运行，不写 gamma 表或保存偏好。无法访问桌面时返回 69，不启动 Cocoa 界面。

下面的恢复进程协议检查也不修改显示器：

```sh
printf clean | "$APP" --watchdog --probe
printf '' | "$APP" --watchdog --probe
```

分别应输出 `clean-exit` 和 `restore-required`。生产模式的 `--watchdog` 在未收到 clean 标记而输入管道关闭时恢复系统 ColorSync。

手动恢复所有显示器的系统 ColorSync 配置（先退出运行中的暮光）：

```sh
"$APP" --restore
```

## 功能范围

支持色温 2700–6500K、软件亮度 30–100%、三个预设、手动/定时模式、30 分钟定时渐变、暂停 15 分钟、一键恢复、登录启动。各支持 gamma 表的显示器使用共同参数；镜像屏跟随源显示器。

色温数值来自近似黑体 RGB 换算，并非硬件校色仪测量值。软件调暗不改变背光。HDR、参考模式、True Tone、其他调色软件及部分显示器需实机验证。

启动调节前记录原始 gamma 表。正常暂停/退出恢复该表；异常退出保护尝试恢复系统 ColorSync 配置。更换色彩配置前应先关闭调节，以免使用旧快照。没有网络请求、账号、遥测或远程更新逻辑。

## 验证范围

已在 macOS 13.4 的受限构建会话通过 1616 项计算测试、10 项模拟显示器生命周期测试、33 项锁屏/唤醒恢复回归检查、11 项旧版登录状态/组件路径测试。新增回归覆盖系统晚些时候重置色彩、显示器就绪延迟、写入失败、临时断屏不叠加暖光、暂停/关闭/白天不被重试覆盖、相互交错的睡眠与会话事件、退出取消任务，以及重试次数有界。主程序与登录辅助程序分别按 Intel 10.15 和 arm64 11.0 构建，并检查两个 Info.plist、四个 Mach-O 架构切片及临时签名。

安装包最低版本检查：

```sh
python3 Tests/VerifyBundle.py ../暮光.app
python3 Tests/VerifyIcon.py ../暮光.app
xcrun swift Tests/IconPixels.swift ../暮光.app/Contents/Resources/MuguangIcon-v021.icns
```

当前会话无法访问桌面显示器，也没有 macOS 10.15 测试系统。界面、实际屏幕调节、登录启动、睡眠唤醒、HDR 和长期稳定性均未完成实机验证。Apple 芯片切片已交叉编译，尚未在 Apple 芯片硬件执行。兼容编译及包内版本检查不等于 Catalina 实机验收。

0.2.1 增量验证通过：图标元数据、ICNS 图层目录、旧式小尺寸图层及透明蒙版、系统解包十种尺寸、每种尺寸的有效图案和透明度。实际 Catalina Finder、Dock、启动台显示以及图标缓存刷新仍需实机确认。图标尺寸和标准打包依据 Apple 的[高分辨率图标说明](https://developer.apple.com/library/archive/documentation/GraphicsAnimation/Conceptual/HighResolutionOSX/Optimizing/Optimizing.html)。

旧系统登录启动采用 Apple 的[嵌入式登录辅助应用方案](https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLoginItems.html)。旧版任务状态查询会产生 SDK 的弃用警告；SDK 注释仍将它推荐用于查询旧式登录项状态。此调用仅在 macOS 13 之前执行。
